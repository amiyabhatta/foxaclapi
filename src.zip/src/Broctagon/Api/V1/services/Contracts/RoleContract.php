<?php

/* 
 * This is for WL Dashboard 
 */
namespace Fox\Services\Contracts;

interface RoleContract {
    
    
    /**
     * list all users
     */
        
    /**
     * User Login
     * @param type $request
     */
  
}

