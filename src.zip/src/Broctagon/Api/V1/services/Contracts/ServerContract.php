<?php

/* 
 * This is for WL Dashboard 
 */
namespace Fox\Services\Contracts;

interface ServerContract {
   
   
}

