<?php

/* 
 * This is for WL Dashboard 
 */
namespace Fox\Services\Contracts;

interface PermissionContract {
    
    
    /**
     * list all users
     */
        
    /**
     * User Login
     * @param type $request
     */
  
}

