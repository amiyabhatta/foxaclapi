<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body ng-app="authApp">
	<div class="container-fluid" id="wrapper">
		<div class="row">
			<nav class="sidebar col-xs-12 col-sm-4 col-lg-3 col-xl-2 bg-faded sidebar-style-1">
                            <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </nav>
			
			<main class="col-xs-12 col-sm-8 offset-sm-4 col-lg-9 offset-lg-3 col-xl-10 offset-xl-2 pt-3 pl-4">
				<header class="page-header row justify-center">
					<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</header>
				<!--
				<section class="row">
                                    <?php echo $__env->yieldContent('content'); ?>
				</section> -->
                                <!--<br><br><br>
                                <a ui-sref="auth()">auth</a><br>
                                <a ui-sref="home()">Home</a><br>
                                <a ui-sref="users()">users</a><br><br><br>-->
                                
                                <div class="container">
                                        <div ui-view></div>
                                </div> 

                            
			</main>
		</div>
	</div>

     <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
 </body>
</html>
