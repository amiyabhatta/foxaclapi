@extends('layouts.default')
@section('content')
    i am the contact page
@stop
