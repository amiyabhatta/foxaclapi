<h1 class="site-title"><a href="index.html"><em class="fa fa-rocket"></em> <img src="assets/images/white_logo_2.png"></a></h1>

                    <a href="#menu-toggle" class="btn btn-default" id="menu-toggle"><em class="fa fa-bars"></em></a>

                    <ul class="nav nav-pills flex-column sidebar-nav">
                        <li class="nav-item"><a class="nav-link active" ui-sref="home()"><em class="fa fa-dashboard"></em> Manage User <span class="sr-only">(current)</span></a></li>
                        <li class="nav-item"><a class="nav-link" ui-sref="roles()"><em class="fa fa-dashboard"></em> Manage Role <span class="sr-only">(current)</span></a></li>
                        <li class="nav-item"><a class="nav-link" ui-sref="permissions()"><em class="fa fa-dashboard"></em> Permission <span class="sr-only">(current)</span></a></li>
                        <li class="nav-item"><a class="nav-link" ui-sref="servers()"><em class="fa fa-dashboard"></em> Server <span class="sr-only">(current)</span></a></li>
                        <li class="nav-item"><a class="nav-link" ui-sref="gateways()"><em class="fa fa-dashboard"></em> Gateway <span class="sr-only">(current)</span></a></li>
                       
                        <!-- <li class="nav-item"><a class="nav-link" href="user-registration.html"><em class="fa user"></em> User Registration</a></li>
                        <li class="nav-item"><a class="nav-link" href="database-management.html"><em class="fa fa-database"></em> Data Base management</a></li>
                        <li class="nav-item"><a class="nav-link" href="gateway-settings.html"><em class="fa fa-globe"></em> Gateway Settings</a></li> -->
                    </ul>